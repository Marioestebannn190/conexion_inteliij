package modulos

import java.time.LocalDate

class Certificado(
    val id: Int,
    var nombre: String,
    var descripcion: String,
    var fechaEmision: LocalDate,
    var fechaExpiracion: LocalDate,
    var usuario: Usuario? = null
) {
    fun estaVigente(): Boolean {
        return LocalDate.now().isBefore(fechaExpiracion)
    }

    fun tiempoRestante(): Long {
        return java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), fechaExpiracion)
    }

    override fun toString(): String {
        return "Certificado(id=$id, nombre='$nombre', descripcion='$descripcion', " +
                "fechaEmision=$fechaEmision, fechaExpiracion=$fechaExpiracion, " +
                "usuario=${usuario?.nombre ?: "No asignado"})"
    }
}
