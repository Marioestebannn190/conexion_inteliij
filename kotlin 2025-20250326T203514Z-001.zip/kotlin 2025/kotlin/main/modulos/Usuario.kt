package modulos

import java.time.LocalDate

class Usuario(
    val id: Int,
    var nombre: String,
    var apellido: String,
    var email: String,
    var fechaRegistro: LocalDate = LocalDate.now(),
    var rol: Rol? = null,
    var certificados: MutableList<Certificado> = mutableListOf()
) {
    fun nombreCompleto(): String {
        return "$nombre $apellido"
    }

    fun asignarCertificado(certificado: Certificado): Boolean {
        if (!certificados.contains(certificado)) {
            certificado.usuario = this
            return certificados.add(certificado)
        }
        return false
    }

    fun removeCertificado(certificado: Certificado): Boolean {
        if (certificados.remove(certificado)) {
            certificado.usuario = null
            return true
        }
        return false
    }

    fun tienePermiso(permiso: String): Boolean {
        return rol?.tienePermiso(permiso) ?: false
    }

    override fun toString(): String {
        return "Usuario(id=$id, nombre='$nombre', apellido='$apellido', email='$email', " +
                "fechaRegistro=$fechaRegistro, rol=${rol?.nombre ?: "No asignado"}, " +
                "certificados=${certificados.size})"
    }
}
