package modulos

class Rol(
    val id: Int,
    var nombre: String,
    var descripcion: String,
    var permisos: MutableList<String> = mutableListOf()
) {
    fun agregarPermiso(permiso: String): Boolean {
        if (!permisos.contains(permiso)) {
            return permisos.add(permiso)
        }
        return false
    }

    fun eliminarPermiso(permiso: String): Boolean {
        return permisos.remove(permiso)
    }

    fun tienePermiso(permiso: String): Boolean {
        return permisos.contains(permiso)
    }

    override fun toString(): String {
        return "Rol(id=$id, nombre='$nombre', descripcion='$descripcion', permisos=$permisos)"
    }
}