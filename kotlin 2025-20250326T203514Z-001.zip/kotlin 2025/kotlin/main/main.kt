package administradorcontroller

import administradorcontroller.CertificadoController
import administradorcontroller.RolController
import administradorcontroller.UsuarioController

fun main() {
    println("Iniciando sistema de administración...")

    // Inicializar controladores
    val certificadoController = CertificadoController()
    val rolController = RolController()
    val usuarioController = UsuarioController()



    println("Sistema listo.")
}