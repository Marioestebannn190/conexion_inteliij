package administradorcontroller

import modulos.Rol

class RolController {
    private val roles = mutableListOf<Rol>()

    fun crearRol(rol: Rol): Boolean {
        return roles.add(rol)
    }

    fun obtenerRoles(): List<Rol> {
        return roles.toList()
    }

    fun obtenerRolPorId(id: Int): Rol? {
        return roles.find { it.id == id }
    }

    fun actualizarRol(id: Int, nuevoRol: Rol): Boolean {
        val index = roles.indexOfFirst { it.id == id }
        if (index != -1) {
            roles[index] = nuevoRol
            return true
        }
        return false
    }

    fun eliminarRol(id: Int): Boolean {
        return roles.removeIf { it.id == id }
    }
}