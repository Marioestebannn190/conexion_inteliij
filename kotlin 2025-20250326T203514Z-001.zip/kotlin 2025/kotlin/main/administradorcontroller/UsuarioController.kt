package administradorcontroller

import modulos.Usuario
import modulos.Rol

class UsuarioController {
    private val usuarios = mutableListOf<Usuario>()

    fun crearUsuario(usuario: Usuario): Boolean {
        return usuarios.add(usuario)
    }

    fun obtenerUsuarios(): List<Usuario> {
        return usuarios.toList()
    }

    fun obtenerUsuarioPorId(id: Int): Usuario? {
        return usuarios.find { it.id == id }
    }

    fun actualizarUsuario(id: Int, nuevoUsuario: Usuario): Boolean {
        val index = usuarios.indexOfFirst { it.id == id }
        if (index != -1) {
            usuarios[index] = nuevoUsuario
            return true
        }
        return false
    }

    fun eliminarUsuario(id: Int): Boolean {
        return usuarios.removeIf { it.id == id }
    }

    fun asignarRol(usuarioId: Int, rol: Rol): Boolean {
        val usuario = obtenerUsuarioPorId(usuarioId)
        if (usuario != null) {
            usuario.rol = rol
            return true
        }
        return false
    }
}
