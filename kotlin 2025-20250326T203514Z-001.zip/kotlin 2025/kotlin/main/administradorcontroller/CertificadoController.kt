package administradorcontroller

import modulos.Certificado

public class CertificadoController {
    private val certificados = mutableListOf<Certificado>()

    fun crearCertificado(certificado: Certificado): Boolean {
        return certificados.add(certificado)
    }

    fun obtenerCertificados(): List<Certificado> {
        return certificados.toList()
    }

    fun obtenerCertificadoPorId(id: Int): Certificado? {
        return certificados.find { it.id == id }
    }

    fun actualizarCertificado(id: Int, nuevoCertificado: Certificado): Boolean {
        val index = certificados.indexOfFirst { it.id == id }
        if (index != -1) {
            certificados[index] = nuevoCertificado
            return true
        }
        return false
    }

    fun eliminarCertificado(id: Int): Boolean {
        return certificados.removeIf { it.id == id }
    }
}ff